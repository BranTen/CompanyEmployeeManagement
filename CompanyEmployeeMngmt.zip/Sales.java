package assignment6;
/**
 * this class is where the information is stored and where it calculates the weekly pay for the specific employee
 * @author Brandon
 */
public class Sales extends Employee
{
	private double sales;
	int h = 0;
	
	public Sales(String firstName, String lastName, String position, double sales, int h, int id) 
	{
		super(firstName, lastName, position, id);
		this.sales = sales; 
		this.h=h;
	}

	public String toString()
	{
		return super.toString();
	}

	@Override
	public double weeklyPay() {
		double total = sales * 0.057;
		
		return total; 
	}



}

