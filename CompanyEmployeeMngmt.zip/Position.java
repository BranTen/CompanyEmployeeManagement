package assignment6;
/**
 * this class is where the values get sent from the employee class
 * @author Brandon
 *
 */
public enum Position {

	MANAGER ("Manager"), SALES ("Sales"), DESIGN ("Design"), MANUFACTURING ("Manufacturing");
	
	String position;
	
	Position ( String position){
		this.position = position;
	}
	public String getPosition(){
		return position;
	}
	public String toString(){
		return position;
	}
}
