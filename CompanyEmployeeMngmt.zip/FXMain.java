package assignment6;

import javafx.scene.control.Button;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * this class creates a gui interface and called methods accordingly
 * 
 * @author Brandon
 *
 */
public class FXMain extends Application {
	// create all of the buttons and text fields and boxes
	TextField id = new TextField();
	TextField firstName = new TextField();
	TextField lastName = new TextField();
	TextField weeklySales = new TextField();
	TextField payRate = new TextField();
	TextField hours = new TextField();
	TextField salary = new TextField();
	TextField quantity = new TextField();
	TextField price = new TextField();
	// --------------------------------------------------------
	Button addEmp = new Button("Add Employee");
	Button clear = new Button("Clear");
	Button remove = new Button("Remove Employee");
	Button printEmp = new Button("Print Company Employee");
	Button printWeek = new Button("Print Weekly Pay Report");
	Button read = new Button("Read File");
	Button exit = new Button("Exit");
	// --------------------------------------------------------
	RadioButton manif = new RadioButton("Manifacturing");
	RadioButton design = new RadioButton("Design");
	RadioButton sales = new RadioButton("Sales");
	RadioButton manager = new RadioButton("Manager");
	// --------------------------------------------------------
	// --------------------------------------------------------
	// --------------------------------------------------------
	HBox bRow1 = new HBox();
	HBox bRow2 = new HBox();
	// --------------------------------------------------------
	VBox main = new VBox();
	// create company object
	Company c = new Company("Wacky Widgets");
	// --------------------------------------------------------
	GridPane gridPane1;
	GridPane gridPane2;
	GridPane gridPane3;
	GridPane saleChoice;
	GridPane manifChoice;
	GridPane designChoice;
	GridPane managerChoice;
	GridPane saleLabel;
	GridPane manifLabel;
	GridPane designLabel;
	GridPane managerLabel;

	// --------------------------------------------------------
	/**
	 * this method is the start method and compiles and designes the gui format
	 */
	@Override
	public void start(Stage stage) {

		// create pane objects
		TitledPane t1 = new TitledPane();
		TitledPane t2 = new TitledPane();

		// declare all of the grid panes
		gridPane1 = new GridPane();
		gridPane2 = new GridPane();
		gridPane3 = new GridPane();
		saleChoice = new GridPane();
		manifChoice = new GridPane();
		designChoice = new GridPane();
		managerChoice = new GridPane();
		saleLabel = new GridPane();
		manifLabel = new GridPane();
		designLabel = new GridPane();
		managerLabel = new GridPane();

		// set all of the specific textfields to not visible
		saleChoice.setVisible(false);
		manifChoice.setVisible(false);
		designChoice.setVisible(false);
		managerChoice.setVisible(false);
		saleLabel.setVisible(false);
		manifLabel.setVisible(false);
		designLabel.setVisible(false);
		managerLabel.setVisible(false);

		// this toggle group lets only one radio button to be pressed at one
		// time
		ToggleGroup position = new ToggleGroup();
		manif.setToggleGroup(position);
		design.setToggleGroup(position);
		sales.setToggleGroup(position);
		manager.setToggleGroup(position);

		// set radio buttons on actions
		manif.setOnAction(new RadioButtonHandler());
		design.setOnAction(new RadioButtonHandler());
		sales.setOnAction(new RadioButtonHandler());
		manager.setOnAction(new RadioButtonHandler());

		// set these buttons on an action
		addEmp.setOnAction(new ButtonHandler());
		clear.setOnAction(new ButtonHandler());
		printEmp.setOnAction(new ButtonHandler());
		printWeek.setOnAction(new ButtonHandler());
		read.setOnAction(new ButtonHandler());
		exit.setOnAction(new ButtonHandler());
		remove.setOnAction(new ButtonHandler());

		// add buttons to the appropriate boxes
		bRow1.getChildren().addAll(addEmp, clear);
		bRow2.getChildren().addAll(printWeek, read);
		bRow1.setAlignment(Pos.CENTER);
		bRow2.setAlignment(Pos.CENTER);

		// set spacing for buttons to make it look pretty
		bRow1.setSpacing(5);
		bRow2.setSpacing(5);

		// place the labels in the gridpanes and the textfields
		gridPane1.add(manif, 0, 0);
		gridPane1.add(design, 1, 0);
		gridPane1.add(sales, 2, 0);
		gridPane1.add(manager, 3, 0);

		// ---------------------------------------------------------------
		// this will add the componenets into the gridpanes
		gridPane2.add(new Label("Employee ID:"), 0, 0);
		gridPane2.add(id, 1, 0);
		gridPane2.add(new Label("First Name:"), 0, 1);
		gridPane2.add(firstName, 1, 1);
		gridPane2.add(new Label("Last Name:"), 0, 2);
		gridPane2.add(lastName, 1, 2);

		// =============================================
		saleLabel.add(new Label("Weekly Sales:"), 0, 4);
		saleChoice.add(weeklySales, 0, 0);

		saleChoice.setHgap(5);
		saleChoice.setVgap(5);
		saleLabel.setHgap(5);
		saleLabel.setVgap(5);
		// -----------------------
		designLabel.add(new Label("Pay Rate:"), 0, 0);
		designChoice.add(payRate, 0, 0);
		designLabel.add(new Label("Hours:"), 0, 1);
		designChoice.add(hours, 0, 1);

		designLabel.setHgap(5);
		designLabel.setVgap(5);

		designChoice.setHgap(5);
		designChoice.setVgap(5);
		// -----------------------
		managerLabel.add(new Label("Salary:"), 0, 4);
		managerChoice.add(salary, 0, 0);
		managerLabel.setHgap(5);
		managerLabel.setVgap(5);
		managerChoice.setHgap(5);
		managerChoice.setVgap(5);
		// -----------------------
		manifLabel.add(new Label("Price:"), 0, 0);
		manifChoice.add(price, 0, 0);
		manifLabel.add(new Label("Quantity:"), 0, 1);
		manifChoice.add(quantity, 0, 1);
		manifLabel.setHgap(5);
		manifLabel.setVgap(7);
		manifChoice.setHgap(5);
		manifChoice.setVgap(5);
		// -----------------------
		gridPane2.add(saleLabel, 0, 3);
		gridPane2.add(saleChoice, 1, 3);
		gridPane2.add(designLabel, 0, 3);
		gridPane2.add(designChoice, 1, 3);
		gridPane2.add(managerLabel, 0, 3);
		gridPane2.add(managerChoice, 1, 3);
		gridPane2.add(manifLabel, 0, 3);
		gridPane2.add(manifChoice, 1, 3);

		gridPane2.add(addEmp, 0, 5);
		gridPane2.add(clear, 1, 5);
		gridPane2.add(remove, 0, 6);

		// ------------------------------------------------------------------
		gridPane3.add(printEmp, 0, 0);
		gridPane3.add(printWeek, 1, 0);
		gridPane3.add(read, 0, 1);
		gridPane3.add(exit, 1, 1);

		// space that out
		gridPane1.setHgap(5);
		gridPane2.setHgap(5);
		gridPane3.setHgap(5);

		gridPane1.setVgap(5);
		gridPane2.setVgap(5);
		gridPane3.setVgap(5);
		// set it to the center
		gridPane1.setAlignment(Pos.CENTER);
		gridPane2.setAlignment(Pos.CENTER);
		saleChoice.setAlignment(Pos.CENTER);
		designChoice.setAlignment(Pos.CENTER);
		manifChoice.setAlignment(Pos.CENTER);
		managerChoice.setAlignment(Pos.CENTER);

		// set the titled panes (title, node)
		t1 = new TitledPane("Position", gridPane1);
		t2 = new TitledPane("Add Employee", gridPane2);
		// set the buttons to the center
		gridPane3.setAlignment(Pos.CENTER);

		// restrict the titled panes
		t1.setMaxWidth(350);
		t2.setMaxWidth(300);
		t2.setMaxHeight(600);

		// make the scene and set the size
		Scene scene = new Scene(main, 600, 400);
		// add the nodes
		main.getChildren().addAll(t1, t2, gridPane3);
		main.setAlignment(Pos.CENTER);
		// set the title of the main stage
		stage.setTitle("Rental Management");
		stage.setScene(scene);
		stage.show(); // show stage

	}

	/**
	 * this method takes the button action and does something with it
	 */
	private class ButtonHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {

			Object button = event.getSource();
			if (button == addEmp) {// if the add employee button is pressed
				String position = "";
				double first = 0;
				int second = 0;
				int Eid;
				// get the text from the correct text fields
				String fName = firstName.getText();
				String lName = lastName.getText();
				Eid = Integer.parseInt(id.getText());
				// depending on what radio button is currently selected
				if (sales.isSelected()) {
					position = "Sales";
					first = Double.parseDouble(weeklySales.getText());
					second = -1;
				} else if (design.isSelected()) {
					position = "Design";
					first = Double.parseDouble(payRate.getText());
					second = Integer.parseInt(hours.getText());
				} else if (manager.isSelected()) {
					position = "Manager";
					first = Double.parseDouble(salary.getText());
					second = -1;
				} else if (manif.isSelected()) {
					position = "Manufacturing";
					first = Double.parseDouble(quantity.getText());
					second = Integer.parseInt(price.getText());
				}
				// call the add employee button while it returns a string error
				// message
				String total = c.addEmployee(fName, lName, position, first,
						second, Eid);
				// if the string it returns in not null then display the error
				// message
				if (total != null) {
					notAddedToString(total);
				} else {// if not then show that employee was added succesfully
					addToString(fName, lName);
				}
			} else if (button == printEmp) {// if the pring employee button is
											// pressed
				printEmpToString();// display message
			} else if (button == printWeek) {// if the pring weekly report
												// button is pressed
				printWeekToString();// display message
			} else if (button == clear) {// if hte clear button is pressed
				// clear all values of the text field
				id.setText("");
				firstName.setText("");
				lastName.setText("");
				weeklySales.setText("");
				payRate.setText("");
				hours.setText("");
				salary.setText("");
				quantity.setText("");
				price.setText("");
			} else if (button == exit) {// if the exit button is pressed
				// exit the program
				Platform.exit();
				System.exit(0);
			} else if (button == read) {// if the read file button is pressed
				try {
					// read the file
					readFile();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			} else if (button == remove) {// if the remove button is pressed
				// remove the employee
				printEmpToString();
				String fName = firstName.getText();
				String lName = lastName.getText();
				// remove the employee based on their name
				removeToString(fName, lName);
			}

		}
	}

	/**
	 * this method displays a pop up box that displays the weekly report
	 */
	private void printWeekToString() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Weekly Report");
		alert.setHeaderText("Weekly Report");
		alert.setContentText(c.generateWeeklyReport());
		alert.showAndWait();
	}

	/**
	 * this method displays a pop up box that displays the list of employees
	 */
	private void printEmpToString() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Employee");
		alert.setHeaderText("Employee List");

		alert.setContentText(c.employeeInfo());
		alert.showAndWait();
	}

	/**
	 * this method displays a pop up box that displays that the employee was not
	 * added
	 */
	private void notAddedToString(String errorMssg) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("error");
		alert.setHeaderText("Employee Not Added");

		alert.setContentText(errorMssg);
		alert.showAndWait();
	}

	/**
	 * this method displays a pop up box that displays the employee was added
	 */
	private void addToString(String fName, String lName) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Employee Addition");
		alert.setHeaderText("Employee Added");

		alert.setContentText(fName + " " + lName + " has been added");
		alert.showAndWait();
	}

	/**
	 * this method displays a pop up box that displays that the employee was
	 * removed
	 */
	private void removeToString(String fName, String lName) {
		c.removeEmployee(fName, lName);
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Employee Removal");
		alert.setHeaderText("Employee Removal");

		alert.setContentText(fName + " " + lName + "has been removed");
		alert.showAndWait();
	}

	/**
	 * this method allows only certian theings to be shown depending on what
	 * radio button is currently selected
	 */
	private class RadioButtonHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {

			if (event.getSource() == manif) {
				manifLabel.setVisible(true);
				saleLabel.setVisible(false);
				designLabel.setVisible(false);
				managerLabel.setVisible(false);

				manifChoice.setVisible(true);
				saleChoice.setVisible(false);
				designChoice.setVisible(false);
				managerChoice.setVisible(false);
			} else if (event.getSource() == sales) {
				manifLabel.setVisible(false);
				saleLabel.setVisible(true);
				designLabel.setVisible(false);
				managerLabel.setVisible(false);

				manifChoice.setVisible(false);
				saleChoice.setVisible(true);
				designChoice.setVisible(false);
				managerChoice.setVisible(false);
			} else if (event.getSource() == design) {
				manifLabel.setVisible(false);
				saleLabel.setVisible(false);
				designLabel.setVisible(true);
				managerLabel.setVisible(false);

				manifChoice.setVisible(false);
				saleChoice.setVisible(false);
				designChoice.setVisible(true);
				managerChoice.setVisible(false);
			} else if (event.getSource() == manager) {
				manifLabel.setVisible(false);
				saleLabel.setVisible(false);
				designLabel.setVisible(false);
				managerLabel.setVisible(true);

				manifChoice.setVisible(false);
				saleChoice.setVisible(false);
				designChoice.setVisible(false);
				managerChoice.setVisible(true);
			}
		}

	}

	/**
	 * this method reads from a file and it stores them in to an array by
	 * seperating values by a colon and then adding it into the employee
	 */
	public void readFile() throws FileNotFoundException {
		FileChooser choice = new FileChooser();
		Scanner in;
		String[] fields;// create array
		// create values for the file to read into
		String fName, lName, pos, line;
		double salary, pay, numSales, price;
		int id, hours, quantity;
		File file = choice.showOpenDialog(null);
		if (file != null) {
			in = new Scanner(file);// scan the file
			while (in.hasNextLine()) {
				line = in.nextLine();// as long as there is a next line
				fields = line.split(":");// split up values by a colon
				// add values into array
				fName = fields[0];
				lName = fields[1];
				pos = fields[2];
				// depending on the poition add values into different
				// constructors
				switch (pos) {
				case "Manager":
					salary = Double.parseDouble(fields[3]);
					id = Integer.parseInt(fields[4]);
					c.addEmployee(fName, lName, "Manager", salary, 0, id);
					break;
				case "Design":
					pay = Double.parseDouble(fields[3]);
					hours = Integer.parseInt(fields[4]);
					id = Integer.parseInt(fields[5]);
					c.addEmployee(fName, lName, "Design", pay, hours, id);
					break;
				case "Sales":
					numSales = Double.parseDouble(fields[3]);
					id = Integer.parseInt(fields[4]);
					c.addEmployee(fName, lName, "Sales", numSales, 0, id);
					break;
				case "Manufacturing":
					price = Double.parseDouble(fields[3]);
					quantity = Integer.parseInt(fields[4]);
					id = Integer.parseInt(fields[5]);
					c.addEmployee(fName, lName, "Manufacturing", price,
							quantity, id);
					break;
				}

			}
		}
	}
}
