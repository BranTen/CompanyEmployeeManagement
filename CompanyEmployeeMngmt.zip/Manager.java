package assignment6;
/**
 * this class is where the information is stored and where it calculates the weekly pay for the specific employee
 * @author Brandon
 */
public class Manager extends Employee
{
	private double pay;
	int h = 0;
	
	public Manager(String firstName, String lastName, String position, double pay, int h, int id) 
	{
		super(firstName, lastName, position, id);
		this.pay = pay;
		this.h = h;
	}
	public String toString()
	{
		return super.toString(); 
	}

	@Override
	public double weeklyPay() {
		// TODO Auto-generated method stub
		return pay;
	}
	
}
