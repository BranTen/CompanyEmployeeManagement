package assignment6;
/**
 * this class is where the information is stored and where it calculates the weekly pay for the specific employee
 * @author Brandon
 */
public class Manufacturing extends Employee
{
	private int numSold;
	private double price;
	
	public Manufacturing(String firstName, String lastName, String position, double price, int numSold, int id) 
	{
		super(firstName, lastName, position , id);
		this.numSold = numSold;
		this.price = price;
	}

	@Override
	public double weeklyPay() 
	{
		double total;
		total = numSold * price;
		return total; 
	}
	

	public String toString()
	{
		return super.toString();
	}

}
