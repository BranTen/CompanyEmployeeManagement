package assignment6;
/**
 * this class is where the information is stored and where it calculates the weekly pay for the specific employee
 * @author Brandon
 */
public class Design extends Employee {

	private double pay=0;
	private int hours=0;
	private final int OVERTIME = 40;
	public Design(String firstName,String lastName,String position, double pay, int hours,int id) {
		super(firstName, lastName, position, id);
		this.pay = pay;
		this.hours = hours;
	}

	public double weeklyPay(){
		double amount = 0;
		if (hours < 40){
			amount = pay * hours;
		}else{
			if(hours > OVERTIME){
				return (pay * 1.5)*(hours);
			}
		}
		return amount;
	}
	public String toString(){
		return super.toString();
	}
	
}
