package assignment6;

import java.util.ArrayList;

/**
 * this class takes in values into a constructor and then passes them down into
 * sub classes
 * 
 * @author Brandon
 *
 */
public class Company implements CompanyInterface {

	private int numEmployee = 0, numManager = 0, numSales = 0, numDesign = 0,
			numManufacturing = 0;

	private String companyName;
	// create an array list
	private ArrayList<Employee> employee = new ArrayList<Employee>();

	// constructor for the name
	public Company(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * this method takes in values and adds them into the array list but if
	 * there are too many of a certian type of employee the method will return a
	 * string that is an error message
	 */
	@Override
	public String addEmployee(String firstName, String lastName,
			String position, double firstParam, int secondParam, int id) {
		// TODO Auto-generated method stub
		String str = null;
		// depending on the position it will call different class constructors
		// because more than one value is
		// specific to that position.
		if (position == "Manager") {
			if (numManager < 1) {
				employee.add(new Manager(firstName, lastName, position,
						firstParam, secondParam, id));
				numManager++;
				numEmployee++;
			} else {
				str = "There is already a Manager\n" + "Employee not added";
			}
		} else if (position == "Design") {
			if (numDesign < 2 && numEmployee < 8) {
				employee.add(new Design(firstName, lastName, position,
						firstParam, secondParam, id));
				numDesign++;
				numEmployee++;
			} else {
				str = "There are already two design persons\n"
						+ "Employee not added";
			}
		} else if (position == "Sales") {
			if (numSales < 1 && numEmployee < 8) {
				employee.add(new Sales(firstName, lastName, position,
						firstParam, secondParam, id));
				numSales++;
				numEmployee++;
			} else {
				str = "There is already a sales person\n"
						+ "Employee not added";
			}
		} else if (position == "Manufacturing") {
			if (numManufacturing < 4) {
				employee.add(new Manufacturing(firstName, lastName, position,
						firstParam, secondParam, id));
				numManufacturing++;
				numEmployee++;
			} else {
				str = "There are already four manufacturing persons\n"
						+ "Employee not added";
			}
		}
		return str;
	}

	/**
	 * this method removes an employee from the array list depending on name
	 * 
	 * @return
	 */
	public boolean removeEmployee(String fName, String lName) {
		boolean y = false;
		for (Employee e : employee) {

			if (e.getFirstName().equals(fName) && e.getLastName().equals(lName)) {
				employee.remove(e);
				y = true;
				break;
			} else {
				y = false;
			}

		}
		return y;
	}

	/**
	 * this method creates a format that makes it easy to undertatnd the format
	 * of the weekly report
	 */

	public String generateWeeklyReport() {
		String totalPayroll;
		String str;
		totalPayroll = String.format("%.2f", calculateTotalWeeklyPay());

		str = "WEEKLY PAY REPORT FOR " + getCompanyName()
				+ " COMPANY \nEMPLOYEE             WEEKLY PAY \n\n"
				+ employeeId() + "Total payroll: $" + totalPayroll + "\n"
				+ "Total number of Managers paid: " + getNumManager() + "\n"
				+ "Total number of Design Employees paid: " + getNumDesign()
				+ "\n" + "Total number of Sales Employees paid: "
				+ getNumSales() + "\n"
				+ "Total number of Manufacturing Employees paid: "
				+ getNumManufacturing() + "\n";

		return str;
	}

	/**
	 * this method returns the employees first and last name and position in a
	 * specific format
	 * 
	 * @return
	 */
	public String employeeInfo() {
		String info = "";
		for (Employee e : employee) {
			info += e.getFirstName() + " " + e.getLastName() + " Position: "
					+ e.getPosition() + "\n";
		}
		return info;
	}

	/**
	 * this method returns the id and weekly pay of employees
	 * 
	 * @return
	 */
	public String employeeId() {
		String info = "";
		for (Employee e : employee) {
			String weeklyPay = String.format("%.2f", e.weeklyPay());

			info += e.getId() + "                            $" + weeklyPay
					+ "\n";
		}
		return info;
	}

	/**
	 * this method calculates the weekly pay of the employees
	 */
	public double calculateTotalWeeklyPay() {
		double calculatedWeeklyPay = 0;
		for (Employee e : employee) {
			calculatedWeeklyPay += e.weeklyPay();
		}
		return calculatedWeeklyPay;
	}

	/**
	 * this method returns the empoyee
	 */
	public String printCompany() {
		String str;
		str = companyName;
		for (Employee e : employee) {
			str = str + "\n" + e + "\n";
		}
		return str;
	}

	public String getCompanyName() {
		// TODO Auto-generated method stub

		return companyName;
	}

	public int getNumEmployee() {
		// TODO Auto-generated method stub

		return numEmployee;
	}

	public int getNumDesign() {
		// TODO Auto-generated method stub

		return numDesign;
	}

	public int getNumManager() {
		// TODO Auto-generated method stub

		return numManager;
	}

	public int getNumManufacturing() {
		// TODO Auto-generated method stub

		return numManufacturing;
	}

	public int getNumSales() {
		return numSales;
	}
}
