package assignment6;
/**
 * this class uses the position of the employee and sends the information to the correct class
 * @author Brandon
 *
 */
public abstract class Employee {
	
	int id;
	String firstName, lastName;
	Position position;
	/**
	 * this method sends values to the correct method
	 * @param firstName
	 * @param lastName
	 * @param pos
	 * @param id
	 */
	public Employee(String firstName, String lastName,String pos, int id) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.id = id;
		if (pos == "Manager"){
			position = Position.MANAGER;
		}else{
			if(pos == "Design"){
				position = Position.DESIGN;
			}else{
				if(pos == "Sales"){
					position = Position.SALES;
				}else{
					if(pos == "Manufacturing"){
						position = Position.MANUFACTURING;
					}
				}
			}
		}
	}

	public abstract double weeklyPay();
	
	public String getFirstName(){
		// TODO Auto-generated method stub

		return firstName;
	}
	public String getLastName(){
		// TODO Auto-generated method stub

		return lastName;
	}
	public int getId(){
		// TODO Auto-generated method stub

		return id;
	}
	public Position getPosition(){
		// TODO Auto-generated method stub

		return position;
	}
	public String toString(){
		// TODO Auto-generated method stub

		String str;
		str = firstName + " " + lastName + " " + "Position: " + position;
		return str;
	}

}
